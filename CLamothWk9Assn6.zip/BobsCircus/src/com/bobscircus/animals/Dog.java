package com.bobscircus.animals;

public class Dog implements Animal, Cloneable {
    private String name;
    private int    age;
    private String species;
    private String color;

    public Dog(String name, int age, String species, String color) {
        this.name    = name;
        this.age     = age;
        this.species = species;
        this.color   = color;
    }

    public Dog(String name, int age) {
        this(name, age, "Dog", "Unknown");
    }

    @Override public String getName()      { return name; }
    @Override public int    getAge()       { return age;  }
    @Override public String move()         { return name + " runs"; }
    @Override public String makeSound()    { return "Woof"; }

    @Override
    public Dog clone() {
        try {
            return (Dog) super.clone();
        } catch (CloneNotSupportedException e) {
            return new Dog(name, age, species, color);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Dog)) return false;
        Dog other = (Dog) o;
        return age == other.age && name.equals(other.name);
    }

    @Override
    public String toString() {
        return "Dog{name='" + name +
               "', age=" + age +
               ", species='" + species +
               "', color='" + color + "'}";
    }
}
