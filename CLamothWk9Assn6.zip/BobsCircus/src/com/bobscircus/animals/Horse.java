package com.bobscircus.animals;

public class Horse implements Animal {
    private String name;
    private int    age;
    private String species;
    private String color;

    public Horse(String name, int age, String species, String color) {
        this.name    = name;
        this.age     = age;
        this.species = species;
        this.color   = color;
    }

    public Horse(String name, int age) {
        this(name, age, "Horse", "Unknown");
    }

    @Override public String getName()      { return name; }
    @Override public int    getAge()       { return age;  }
    @Override public String move()         { return name + " gallops"; }
    @Override public String makeSound()    { return "Neigh"; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Horse)) return false;
        Horse other = (Horse) o;
        return age == other.age && name.equals(other.name);
    }

    @Override
    public String toString() {
        return "Horse{name='" + name +
               "', age=" + age +
               ", species='" + species +
               "', color='" + color + "'}";
    }
}
