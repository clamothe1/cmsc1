package com.bobscircus.core;

import com.bobscircus.animals.Animal;
import com.bobscircus.people.Person;
import com.bobscircus.buildings.Building;
import com.bobscircus.tickets.Ticket;

import java.util.*;

public class Circus {
    private List<Animal>   animals   = new ArrayList<>();
    private List<Person>   persons   = new ArrayList<>();
    private List<Building> buildings = new ArrayList<>();
    private List<Ticket>   tickets   = new ArrayList<>();

    public void addAnimal(Animal a)       { animals.add(a); }
    public void addPerson(Person p)       { persons.add(p); }
    public void addBuilding(Building b)   { buildings.add(b); }
    public void addTicket(Ticket t)       { tickets.add(t); }

    public void displayAnimals() {
        animals.forEach(System.out::println);
    }
    public void displayPersons() {
        persons.forEach(System.out::println);
    }
    public void displayBuildings() {
        buildings.forEach(System.out::println);
    }
    public void displayTickets() {
        tickets.forEach(System.out::println);
    }

    public void sortAnimalsByAge() {
        animals.sort(Comparator.comparingInt(Animal::getAge));
    }
    public void sortAnimalsByName() {
        animals.sort(Comparator.comparing(Animal::getName));
    }

    public List<Animal> searchAnimalsByName(String name) {
        List<Animal> result = new ArrayList<>();
        for (Animal a : animals) {
            if (a.getName().equalsIgnoreCase(name)) {
                result.add(a);
            }
        }
        return result;
    }

    public Ticket generateTicket(String day, double price, int age) {
        Ticket t = new Ticket(day, price, age);
        tickets.add(t);
        return t;
    }
}
