package com.bobscircus.core;

import com.bobscircus.animals.*;
import com.bobscircus.people.*;
import com.bobscircus.buildings.*;
import com.bobscircus.tickets.*;

import java.util.Scanner;

public class CircusDriverApp {
    private static Circus circus = new Circus();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n=== Bob's Circus Menu ===");
            System.out.println("1. Add Animal");
            System.out.println("2. Add Person");
            System.out.println("3. Add Building");
            System.out.println("4. Generate Ticket");
            System.out.println("5. Display Animals");
            System.out.println("6. Display Persons");
            System.out.println("7. Display Buildings");
            System.out.println("8. Display Tickets");
            System.out.println("9. Sort Animals by Age");
            System.out.println("10. Sort Animals by Name");
            System.out.println("11. Search Animal by Name");
            System.out.println("12. Exit");
            System.out.print("Choose an option: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    handleAddAnimal();
                    break;
                case 2:
                    handleAddPerson();
                    break;
                case 3:
                    handleAddBuilding();
                    break;
                case 4:
                    handleGenerateTicket();
                    break;
                case 5:
                    circus.displayAnimals();
                    break;
                case 6:
                    circus.displayPersons();
                    break;
                case 7:
                    circus.displayBuildings();
                    break;
                case 8:
                    circus.displayTickets();
                    break;
                case 9:
                    circus.sortAnimalsByAge();
                    System.out.println("Animals sorted by age.");
                    break;
                case 10:
                    circus.sortAnimalsByName();
                    System.out.println("Animals sorted by name.");
                    break;
                case 11:
                    System.out.print("Enter name to search: ");
                    String name = scanner.nextLine();
                    System.out.println(circus.searchAnimalsByName(name));
                    break;
                case 12:
                    exit = true;
                    break;
                default:
                    System.out.println("Please choose a valid option (1–12).");
            }
        }
        System.out.println("Goodbye!");
    }

    private static void handleAddAnimal() {
        System.out.print("Enter animal type (Dog/Horse/Bird/Lion): ");
        String type = scanner.nextLine().trim();
        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter age: ");
        int age = Integer.parseInt(scanner.nextLine());

        Animal a;
        switch (type.toLowerCase()) {
            case "dog":   a = new Dog(name, age);   break;
            case "horse": a = new Horse(name, age); break;
            case "bird":  a = new Bird(name, age);  break;
            case "lion":  a = new Lion(name, age);  break;
            default:
                System.out.println("Invalid animal type.");
                return;
        }

        circus.addAnimal(a);
        System.out.println(type + " added: " + a);
    }

    private static void handleAddPerson() {
        System.out.print("Enter person type (Clerk/Acrobatic): ");
        String type = scanner.nextLine().trim();
        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter age: ");
        int age = Integer.parseInt(scanner.nextLine());

        Person p;
        switch (type.toLowerCase()) {
            case "clerk":
                System.out.print("Enter employee ID: ");
                int id = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter job title: ");
                String title1 = scanner.nextLine().trim();
                p = new Clerk(name, age, id, title1);
                break;
            case "acrobatic":
                System.out.print("Enter years worked: ");
                int years = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter job title: ");
                String title2 = scanner.nextLine().trim();
                p = new Acrobatic(name, age, years, title2);
                break;
            default:
                System.out.println("Invalid person type.");
                return;
        }

        circus.addPerson(p);
        System.out.println(type + " added: \n" + p);
    }

    private static void handleAddBuilding() {
        System.out.print("Enter building type (Arena/TicketingOffice): ");
        String type = scanner.nextLine().trim();
        System.out.print("Enter color: ");
        String color = scanner.nextLine().trim();
        System.out.print("Enter length: ");
        double length = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter width: ");
        double width = Double.parseDouble(scanner.nextLine());

        Building b;
        switch (type.toLowerCase()) {
            case "arena":
                b = new Arena(color, length, width);
                break;
            case "ticketingoffice":
            case "ticketing office":
                b = new TicketingOffice(color, length, width);
                break;
            default:
                System.out.println("Invalid building type.");
                return;
        }

        circus.addBuilding(b);
        System.out.println(type + " added: " + b);
    }

    private static void handleGenerateTicket() {
        System.out.print("Enter base ticket price: ");
        double basePrice = Double.parseDouble(scanner.nextLine());

        boolean more = true;
        while (more) {
            System.out.print("Enter day of week (e.g. Monday): ");
            String day = scanner.nextLine().trim();
            System.out.print("Enter customer age: ");
            int age = Integer.parseInt(scanner.nextLine());

            Ticket t = circus.generateTicket(day, basePrice, age);
            System.out.println("Ticket generated: " + t);

            System.out.print("Add another ticket? (y/n): ");
            more = scanner.nextLine().trim().equalsIgnoreCase("y");
        }
    }
}
