package com.bobscircus.exceptions;

import java.util.InputMismatchException;
public class CustomInputMismatchException extends InputMismatchException {
    private static final long serialVersionUID = 1L;

    public CustomInputMismatchException(String message) {
        super(message);
    }
}


