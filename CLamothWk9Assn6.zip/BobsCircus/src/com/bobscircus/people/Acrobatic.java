// src/com/bobscircus/people/Acrobatic.java
package com.bobscircus.people;

public class Acrobatic extends Person {
    private int    yearsWorked;
    private String jobTitle;

    public Acrobatic(String name, int age, int yearsWorked, String jobTitle) {
        super(name, age);
        this.yearsWorked = yearsWorked;
        this.jobTitle    = jobTitle;
    }

    public int    getYearsWorked() { return yearsWorked; }
    public String getJobTitle()    { return jobTitle;     }

    @Override
    public String toString() {
        return "Name: " + getName()   + "\n"
             + "Age: "  + getAge()    + "\n"
             + "Years Worked: " + yearsWorked + "\n"
             + "Job: " + jobTitle;
    }
}
