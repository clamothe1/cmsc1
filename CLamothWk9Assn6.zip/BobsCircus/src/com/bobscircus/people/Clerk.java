package com.bobscircus.people;

public class Clerk extends Person {
    private int    employeeId;
    private String jobTitle;

    public Clerk(String name, int age, int employeeId, String jobTitle) {
        super(name, age);
        this.employeeId = employeeId;
        this.jobTitle   = jobTitle;
    }

    public int    getEmployeeId() { return employeeId; }
    public String getJobTitle()   { return jobTitle;  }

    @Override
    public String toString() {
        return "Name: " + getName() + "\n"
             + "Age: "  + getAge()  + "\n"
             + "Employee ID: " + employeeId + "\n"
             + "Job: " + jobTitle;
    }
}
