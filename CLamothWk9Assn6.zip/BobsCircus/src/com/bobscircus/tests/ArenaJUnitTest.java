package com.bobscircus.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bobscircus.buildings.Arena;

public class ArenaJUnitTest {

    private Arena arena;

    @BeforeEach
    void setUp() {
        arena = new Arena("Blue", 100.0, 50.0);
    }

    @Test
    //testConstructor()
    void testConstructor() {
        //testConstructor();
    }

    @Test
    //testSetSize()
    void testSetSize() {
        //testSetSize();
    }

    @Test
    //testGetLength()
    void testGetLength() {
        //testGetLength();
    }

    @Test
    //testGetWidth()
    void testGetWidth() {
        //testGetWidth();
    }

    @Test
    //testSetColor()
    void testSetColor() {
        //testSetColor();
    }

    @Test
    //testGetColor()
    void testGetColor() {
        //testGetColor();
    }

    @Test
    //testSetBuildingType()
    void testSetBuildingType() {
        //testSetBuildingType();
    }

    @Test
    //testGetBuildingType()
    void testGetBuildingType() {
        //testGetBuildingType();
    }

    @Test
    //testToString()
    void testToString() {
        //testToString();
    }
}
