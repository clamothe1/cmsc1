package com.bobscircus.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bobscircus.core.Circus;

public class CircusDriverAppJUnitTest {

    private Circus circus;

    @BeforeEach
    void setUp() {
        circus = new Circus();
    }

    @Test
    //testAddAndDisplayAnimals()
    void testAddAndDisplayAnimals() {
        //testAddAndDisplayAnimals();
    }

    @Test
    //testAddAndDisplayPersons()
    void testAddAndDisplayPersons() {
        //testAddAndDisplayPersons();
    }

    @Test
    //testAddAndDisplayBuildings()
    void testAddAndDisplayBuildings() {
        //testAddAndDisplayBuildings();
    }

    @Test
    //testGenerateAndDisplayTickets()
    void testGenerateAndDisplayTickets() {
        //testGenerateAndDisplayTickets();
    }

    @Test
    //testSortAnimalsByAge()
    void testSortAnimalsByAge() {
        //testSortAnimalsByAge();
    }

    @Test
    //testSortAnimalsByName()
    void testSortAnimalsByName() {
        //testSortAnimalsByName();
    }

    @Test
    //testSearchAnimalByName()
    void testSearchAnimalByName() {
        //testSearchAnimalByName();
    }

    @Test
    //testAddAndDisplayTickets()
    void testAddAndDisplayTickets() {
        //testAddAndDisplayTickets();
    }
}
