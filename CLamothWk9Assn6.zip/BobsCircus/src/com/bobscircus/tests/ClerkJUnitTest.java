package com.bobscircus.tests;

import org.junit.jupiter.api.Test;

public class ClerkJUnitTest {

    @Test
    public void testConstructorAndInheritedGetters() {
        // Create an instance of Clerk
        // Test inherited fields and getters
        // …
    }

    @Test
    public void testToString() {
        // …
    }
}
