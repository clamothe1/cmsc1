package com.bobscircus.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bobscircus.animals.Dog;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class DogJUnitTest {

    private Dog dog;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    void setUp() {
        //setUp()
        dog = new Dog("Rex", 3, "Dog", "Black");
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    //testGetName()
    void testGetName() {
        //testGetName();
    }

    @Test
    //testGetAge()
    void testGetAge() {
        //testGetAge();
    }

    @Test
    //testMove()
    void testMove() {
        //testMove();
    }

    @Test
    //testMakeSound()
    void testMakeSound() {
        //testMakeSound();
    }

    @Test
    //testEquals()
    void testEquals() {
        //testEquals();
    }

    @Test
    //testToString()
    void testToString() {
        //testToString();
    }

    @Test
    //testClone()
    void testClone() {
        //testClone();
    }

    @BeforeEach
    void resetOutputStream() {
        outputStream.reset();
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
        System.setOut(originalOut);
    }
}
