package com.bobscircus.tests;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bobscircus.animals.Horse;

class HorseJUnitTest {

    private Horse horse;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    //setUp()
    void setUp() {
        horse = new Horse("Spirit", 7, "Horse", "Brown");
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    //testGetName()
    void testGetName() {
        //testGetName();
    }

    @Test
    //testGetAge()
    void testGetAge() {
        //testGetAge();
    }

    @Test
    //testMove()
    void testMove() {
        //testMove();
    }

    @Test
    //testMakeSound()
    void testMakeSound() {
        //testMakeSound();
    }

    @Test
    //testEquals()
    void testEquals() {
        //testEquals();
    }

    @Test
    //testToString()
    void testToString() {
        //testToString();
    }

    @BeforeEach
    void resetOutputStream() {
        outputStream.reset();
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
        System.setOut(originalOut);
    }
}
