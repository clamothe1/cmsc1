package com.bobscircus.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bobscircus.animals.Lion;

public class LionJUnitTest {

    private Lion lion1;
    private Lion lion2;

    @BeforeEach
    void setUp() {
        lion1 = new Lion("Simba", 5, "Lion", "Golden");
        lion2 = new Lion("King",  8, "Lion", "White");
    }

    @Test
    //testGetName()
    void testGetName() {
        //testGetName();
    }

    @Test
    //testGetAge()
    void testGetAge() {
        //testGetAge();
    }

    @Test
    //testMove()
    void testMove() {
        //testMove();
    }

    @Test
    //testMakeSound()
    void testMakeSound() {
        //testMakeSound();
    }

    @Test
    //testEquals()
    void testEquals() {
        //testEquals();
    }

    @Test
    //testToString()
    void testToString() {
        //testToString();
    }
}
