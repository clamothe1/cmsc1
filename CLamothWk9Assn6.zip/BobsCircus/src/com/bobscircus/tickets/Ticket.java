package com.bobscircus.tickets;

public class Ticket {
    private double  basePrice;
    private String  dayOfWeek;
    private int     age;

    public Ticket(String dayOfWeek, double basePrice, int age) {
        this.basePrice = basePrice;
        this.age       = age;
        this.dayOfWeek = dayOfWeek.trim().toUpperCase();
    }

    public double calculatePrice() {
        DayOfWeek d = DayOfWeek.valueOf(dayOfWeek);
        return basePrice * (1.0 - d.getDiscount());
    }

    public void displayTicketDetails() {
        String dayCap = dayOfWeek.charAt(0) + dayOfWeek.substring(1).toLowerCase();
        System.out.printf(
          "Ticket Details: [Age: %d, Day: %s, Price: $%.2f]%n",
          age, dayCap, calculatePrice()
        );
    }

    @Override
    public String toString() {
        String dayCap = dayOfWeek.charAt(0) + dayOfWeek.substring(1).toLowerCase();
        return String.format(
          "Ticket [Day: %s, Age: %d, Price: $%.2f]",
          dayCap, age, calculatePrice()
        );
    }
}
